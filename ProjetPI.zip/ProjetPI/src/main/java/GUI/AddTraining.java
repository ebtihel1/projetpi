package GUI;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import models.Formation;
import services.FormationService;

import java.sql.SQLException;

public class AddTraining {

    @FXML
    private Button Add_training;

    @FXML
    private Button Available_trainig;

    @FXML
    private Button Dashboard;

    @FXML
    private TextField DomaineTextfield;

    @FXML
    private Button ImportImage;

    @FXML
    private TextField montantTextField;

    @FXML
    private TextField nomTextField;

    @FXML
    private TextField search;

    @FXML
    private Label signout;

    @FXML
    void Afficher(ActionEvent event) {

    }

    @FXML
    void Ajouter(ActionEvent event) {



        Formation formation=new Formation(nomTextField.getText(),DomaineTextfield.getText(),Double.parseDouble(montantTextField.getText()));
        FormationService Formationservice=new FormationService();
        try {
            Formationservice.ajouter(formation);
            Alert alert=new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("la formation a été ajouté avec succés !");
            alert.show();
        } catch (SQLException e) {
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setContentText(e.getMessage());
            alert.show();
        }

    }

    @FXML
    void modifier(ActionEvent event) {
        Formation formation=new Formation(nomTextField.getText(),DomaineTextfield.getText(),Double.parseDouble(montantTextField.getText()));
        FormationService Formationservice=new FormationService();
        try {
            Formationservice.modifier(formation);
            Alert alert=new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("la formation  a été modifié avec succés !");
            alert.show();
        } catch (SQLException e) {
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setContentText(e.getMessage());
            alert.show();
        }

    }

    @FXML
    void supprimer(ActionEvent event) {
        Formation formation=new Formation(nomTextField.getText(),DomaineTextfield.getText(),Double.parseDouble(montantTextField.getText()));
        FormationService Formationservice=new FormationService();
        try {
            Formationservice.supprimer(formation.getId());
            Alert alert=new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("la formation  a été supprimé avec succés !");
            alert.show();
        } catch (SQLException e) {
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setContentText(e.getMessage());
            alert.show();
        }

    }

}
