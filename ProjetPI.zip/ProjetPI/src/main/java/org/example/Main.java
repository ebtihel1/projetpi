package org.example;
import models.Formation;
import services.FormationService;

import utils.Mydatabase;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {

       // Mydatabase d = Mydatabase.getInstance();}
        FormationService Fs=new FormationService();
        try {
            Fs.ajouter(new Formation("java","for",25.2 ));
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
        try {
            Fs.modifier(new Formation(1,"python","informatique",750));
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
        try {

            System.out.println(Fs.recuperer());
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
}}

